## q2: Pipeline

Usage: ```bash q2.sh <reference genome>.fa <short reads 1>.fastq <short reads 2>.fastq```

Sources: https://samtools.github.io/bcftools/howtos/variant-calling.html for ```bcftools``` usage